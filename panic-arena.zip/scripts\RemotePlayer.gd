extends Node3D
## RemotePlayer
##
## A networked avatar for someone else in the match. Holds the latest synced
## transform and smoothly interpolates toward it between sync ticks (~100ms),
## so movement looks continuous despite the discrete updates.

const LERP_SPEED := 12.0

var peer_id: int = -1
var role: int = GameManager.Role.HUNTED
var target_position: Vector3 = Vector3.ZERO
var target_yaw: float = 0.0
var last_seen_ms: int = 0

@onready var _mesh: MeshInstance3D = $Mesh


func setup(p_peer_id: int, p_role: int) -> void:
	peer_id = p_peer_id
	apply_role(p_role)


func apply_role(p_role: int) -> void:
	role = p_role
	if role == GameManager.Role.GHOST:
		var mat := StandardMaterial3D.new()
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.albedo_color = Color(0.8, 0.0, 0.0, 0.35)
		_mesh.material_override = mat


func receive(pos: Vector3, yaw: float) -> void:
	target_position = pos
	target_yaw = yaw
	last_seen_ms = Time.get_ticks_msec()


func _process(delta: float) -> void:
	var t := clampf(LERP_SPEED * delta, 0.0, 1.0)
	global_position = global_position.lerp(target_position, t)
	rotation.y = lerp_angle(rotation.y, target_yaw, t)
