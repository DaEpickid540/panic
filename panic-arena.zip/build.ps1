# Panic: Arena — HTML5/PWA build helper (Windows / PowerShell).
#
# Prereqs:
#   - Godot 4.6.3 reachable. Set $env:GODOT or rely on `godot` on PATH.
#   - Web export templates installed (Editor > Manage Export Templates).
#
# Usage:  .\build.ps1            (release)
#         .\build.ps1 debug
param([string]$Mode = "release")

$ErrorActionPreference = "Stop"
$Godot = if ($env:GODOT) { $env:GODOT } else { "godot" }
$Out = "build/html5"

New-Item -ItemType Directory -Force -Path $Out | Out-Null

Write-Host "==> Exporting Web preset ($Mode) with $Godot"
if ($Mode -eq "debug") {
  & $Godot --headless --export-debug "Web" "$Out/index.html"
} else {
  & $Godot --headless --export-release "Web" "$Out/index.html"
}

Write-Host "==> Overlaying PWA shell"
Copy-Item pwa/manifest.json "$Out/manifest.json" -Force
Copy-Item pwa/service-worker.js "$Out/service-worker.js" -Force
New-Item -ItemType Directory -Force -Path "$Out/icons" | Out-Null
$icons = Get-ChildItem pwa/icons/*.png -ErrorAction SilentlyContinue
if ($icons) { Copy-Item pwa/icons/*.png "$Out/icons/" -Force }
else { Write-Host "    (no PNG icons yet - add pwa/icons/icon-192.png + icon-512.png)" }

Write-Host "==> Done. Serve with:  python -m http.server 8000 --directory $Out"
