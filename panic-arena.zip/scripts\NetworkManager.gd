extends Node
## NetworkManager (autoload singleton)
##
## Manages the local player's identity and the roster of peers in the room.
## Firebase Realtime DB is the transport (see GameStateSync / PositionSync),
## so this layer is intentionally light — no ENet/high-level multiplayer.

signal peer_joined(peer_id: int)
signal peer_left(peer_id: int)
signal local_id_assigned(peer_id: int)

var local_peer_id: int = -1
var peers: Dictionary = {}   # peer_id -> { name: String, joined_at: int }
var current_room: String = ""


func _ready() -> void:
	# Stable-ish client id; replace with hashed Firebase auth uid later.
	local_peer_id = abs(int(Time.get_unix_time_from_system() * 1000.0)) % 1000000
	register_peer(local_peer_id, "You")
	local_id_assigned.emit(local_peer_id)


func host_room() -> String:
	current_room = _generate_room_code()
	GameManager.set_host(true)
	GameStateSync.join_room(current_room)
	return current_room


func join_room(room_id: String, display_name: String = "Player") -> void:
	current_room = room_id
	GameManager.set_host(false)
	peers[local_peer_id]["name"] = display_name
	GameStateSync.join_room(room_id)


func register_peer(peer_id: int, display_name: String) -> void:
	if peers.has(peer_id):
		return
	peers[peer_id] = {"name": display_name, "joined_at": Time.get_ticks_msec()}
	peer_joined.emit(peer_id)


func remove_peer(peer_id: int) -> void:
	if peer_id == local_peer_id:
		return
	if peers.erase(peer_id):
		peer_left.emit(peer_id)


func get_peer_ids() -> Array:
	return peers.keys()


func get_peer_count() -> int:
	return peers.size()


func get_peer_name(peer_id: int) -> String:
	return peers.get(peer_id, {}).get("name", "Player %d" % peer_id)


## Editor/testing helper: fake N extra players so phase + role logic can be
## exercised solo with F5. Call from LobbyUI's "Add Bot" button.
func add_test_peer(display_name: String = "") -> int:
	var id := randi() % 900000 + 100000
	register_peer(id, display_name if display_name != "" else "Bot %d" % (peers.size()))
	return id


func _generate_room_code() -> String:
	const CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	var code := ""
	for i in 6:
		code += CHARS[randi() % CHARS.length()]
	return code
