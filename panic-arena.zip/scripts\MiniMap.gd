extends Control
## MiniMap — 150x150 top-down radar for the HUNTER.
##   red dot   = hunter (self)
##   white dot = hunted
##   red ring  = ghost
## Dots refresh every 500 ms from synced positions (the GameController spawner).

const REFRESH := 0.5
const WORLD_HALF := 25.0   # MapBase HALF

var _spawner: Node
var _accum := 0.0


func _ready() -> void:
	var gc := get_tree().get_first_node_in_group("game_controller")
	if gc:
		_spawner = gc.get_node_or_null("PlayerSpawner")


func _process(delta: float) -> void:
	_accum += delta
	if _accum >= REFRESH:
		_accum = 0.0
		queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.06, 0.06, 0.06, 0.85))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.8, 0, 0, 0.8), false, 2.0)
	if _spawner == null or _spawner.local_player == null:
		return
	# Self (hunter).
	_dot(_spawner.local_player.global_position, Color(0.8, 0, 0), 4.0, true)
	for peer_id in _spawner.remotes:
		var rp = _spawner.remotes[peer_id]
		if rp.role == GameManager.Role.GHOST:
			_dot(rp.global_position, Color(0.8, 0, 0), 4.0, false)
		else:
			_dot(rp.global_position, Color(1, 1, 1), 3.0, true)


func _dot(world: Vector3, color: Color, r: float, filled: bool) -> void:
	var u := (world.x / WORLD_HALF * 0.5 + 0.5) * size.x
	var v := (world.z / WORLD_HALF * 0.5 + 0.5) * size.y
	var p := Vector2(u, v)
	if filled:
		draw_circle(p, r, color)
	else:
		draw_arc(p, r, 0, TAU, 16, color, 1.5)
