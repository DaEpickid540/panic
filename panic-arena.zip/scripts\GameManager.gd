extends Node
## GameManager (autoload singleton)
##
## Authority on the *local* mirror of the match. Drives the phase machine:
##   LOBBY -> COUNTDOWN (5s) -> HUNTING (5-20 min) -> END
## and owns role assignment (1 hunter, rest hunted, hunted -> ghost on capture).
##
## Everything here is testable in the editor with NO Firebase: call
## start_countdown() / force_phase() and watch the signals fire. When Firebase
## is connected, GameStateSync mirrors phase + roles + timeRemaining so all
## clients agree (the host is authoritative; clients apply remote phase).

signal phase_changed(new_phase: int, old_phase: int)
signal countdown_started(seconds: int)
signal countdown_tick(seconds_left: int)
signal hunting_started()
signal hunting_tick(seconds_left: int)
signal game_ended(results: Dictionary)
signal role_assigned(peer_id: int, role: int)
signal player_captured(peer_id: int, by_peer_id: int)

enum Phase { LOBBY, COUNTDOWN, HUNTING, END }
enum Role { HUNTER, HUNTED, GHOST }

const ROLE_NAMES := {
	Role.HUNTER: "hunter",
	Role.HUNTED: "hunted",
	Role.GHOST: "ghost",
}

const COUNTDOWN_SECONDS := 5
const MIN_ROUND_MINUTES := 5
const MAX_ROUND_MINUTES := 20
const DEFAULT_ROUND_MINUTES := 5

var current_phase: int = Phase.LOBBY
## User-settable round length (clamped to 5..20). Default 5 min.
var round_minutes: int = DEFAULT_ROUND_MINUTES
var selected_map: String = "Urban"

var roles: Dictionary = {}              # peer_id (int) -> Role
var capture_times: Dictionary = {}      # peer_id -> seconds survived
var capture_counts: Dictionary = {}     # hunter peer_id -> captures made

var _phase_timer: Timer
var _seconds_left: int = 0
var _is_host: bool = true                # set false when joining a remote room


func _ready() -> void:
	_phase_timer = Timer.new()
	_phase_timer.one_shot = false
	_phase_timer.wait_time = 1.0
	_phase_timer.timeout.connect(_on_tick)
	add_child(_phase_timer)


## --- Configuration -------------------------------------------------------

func set_round_minutes(minutes: int) -> void:
	round_minutes = clampi(minutes, MIN_ROUND_MINUTES, MAX_ROUND_MINUTES)


func set_host(is_host: bool) -> void:
	_is_host = is_host


func get_round_seconds() -> int:
	return round_minutes * 60


## --- Phase machine -------------------------------------------------------

func force_phase(phase: int) -> void:
	# Editor/testing entry point and the path used when applying a remote phase.
	_enter_phase(phase)


## Host-driven happy path: lobby -> countdown.
func start_game() -> void:
	if current_phase != Phase.LOBBY:
		return
	start_countdown()


func start_countdown() -> void:
	_seconds_left = COUNTDOWN_SECONDS
	_enter_phase(Phase.COUNTDOWN)
	countdown_started.emit(COUNTDOWN_SECONDS)
	_phase_timer.start()


func start_hunting() -> void:
	if _is_host:
		assign_roles(NetworkManager.get_peer_ids())
	_seconds_left = get_round_seconds()
	_enter_phase(Phase.HUNTING)
	hunting_started.emit()
	_phase_timer.start()


func end_game(reason: String = "timer") -> void:
	_phase_timer.stop()
	_enter_phase(Phase.END)
	game_ended.emit(build_results(reason))


func _enter_phase(phase: int) -> void:
	if phase == current_phase:
		return
	var old := current_phase
	current_phase = phase
	phase_changed.emit(phase, old)
	if _is_host:
		GameStateSync.push_phase(phase, _seconds_left)


func _on_tick() -> void:
	_seconds_left -= 1
	match current_phase:
		Phase.COUNTDOWN:
			countdown_tick.emit(_seconds_left)
			if _seconds_left <= 0:
				start_hunting()
		Phase.HUNTING:
			hunting_tick.emit(_seconds_left)
			if _is_host:
				GameStateSync.push_time_remaining(_seconds_left)
			if _seconds_left <= 0:
				end_game("timer")


func get_seconds_left() -> int:
	return _seconds_left


func apply_remote_time(seconds_left: int) -> void:
	# Clients trust the host's clock to avoid drift.
	if not _is_host:
		_seconds_left = seconds_left


## --- Role logic ----------------------------------------------------------

## One hunter at random; everyone else hunted. Mirrors to Firebase.
func assign_roles(peer_ids: Array) -> void:
	roles.clear()
	capture_times.clear()
	capture_counts.clear()
	if peer_ids.is_empty():
		return
	var pool := peer_ids.duplicate()
	pool.shuffle()
	var hunter_id: int = pool[0]
	for id in peer_ids:
		var r: int = Role.HUNTER if id == hunter_id else Role.HUNTED
		roles[id] = r
		if r == Role.HUNTER:
			capture_counts[id] = 0
		role_assigned.emit(id, r)
	GameStateSync.push_roles(roles)


func apply_remote_roles(remote_roles: Dictionary) -> void:
	for id in remote_roles:
		var r: int = remote_roles[id]
		if roles.get(id) != r:
			roles[id] = r
			role_assigned.emit(id, r)


func get_role(peer_id: int) -> int:
	return roles.get(peer_id, Role.HUNTED)


func get_local_role() -> int:
	return get_role(NetworkManager.local_peer_id)


## Convert a captured hunted player into a ghost. Records stats and checks
## the end condition. Capture SFX is fired by CaptureDetector/AudioManager.
func capture_player(peer_id: int, by_peer_id: int) -> void:
	if get_role(peer_id) != Role.HUNTED:
		return
	roles[peer_id] = Role.GHOST
	capture_times[peer_id] = get_round_seconds() - _seconds_left
	if capture_counts.has(by_peer_id):
		capture_counts[by_peer_id] += 1
	role_assigned.emit(peer_id, Role.GHOST)
	player_captured.emit(peer_id, by_peer_id)
	GameStateSync.push_capture(peer_id, by_peer_id)
	if _is_host:
		GameStateSync.push_roles(roles)
		_check_end_condition()


func _check_end_condition() -> void:
	var hunted_left := 0
	for id in roles:
		if roles[id] == Role.HUNTED:
			hunted_left += 1
	if hunted_left == 0:
		end_game("all_captured")


## --- Results -------------------------------------------------------------

func build_results(reason: String = "timer") -> Dictionary:
	var survivors: Array = []
	var stats: Array = []
	var longest := 0
	for id in roles:
		var survived: int = capture_times.get(id, get_round_seconds() - _seconds_left)
		var role_name: String = ROLE_NAMES[roles[id]]
		if roles[id] == Role.HUNTED:
			survivors.append(id)
			survived = get_round_seconds() - _seconds_left
		longest = maxi(longest, survived)
		stats.append({
			"peer_id": id,
			"name": NetworkManager.get_peer_name(id),
			"role": role_name,
			"survival_time": survived,
			"captures": capture_counts.get(id, 0),
		})
	return {
		"reason": reason,
		"survivors": survivors,
		"survivor_count": survivors.size(),
		"longest_survival": longest,
		"stats": stats,
	}
