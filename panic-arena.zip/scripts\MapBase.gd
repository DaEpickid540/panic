extends Node3D
## MapBase
##
## Procedurally builds a 50x50 m arena from primitives so the game is fully
## playable with ZERO external assets. Each map variant (Urban / Forest /
## Warehouse / Mansion) sets `style` + palette; the layout (size, collision,
## spawn points) is identical across maps for fair play.
##
## Swap-in path for real assets: replace _make_obstacle()'s primitive with an
## instanced Quaternius .glb and keep the same transform/collision. See ASSETS.md.

enum Style { URBAN, FOREST, WAREHOUSE, MANSION }

const ARENA_SIZE := 50.0
const HALF := ARENA_SIZE * 0.5
const WALL_HEIGHT := 6.0
const OBSTACLE_COUNT := 18
const PERIMETER_SPAWNS := 8

const RED := Color(0.8, 0.0, 0.0)          # #CC0000

@export var style: Style = Style.URBAN
@export var ground_color: Color = Color(0.18, 0.18, 0.18)
@export var obstacle_color: Color = Color(0.12, 0.12, 0.12)
@export var seed_value: int = 1337

var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.seed = seed_value
	_build_environment()
	_build_floor()
	_build_walls()
	_build_obstacles()
	_build_spawns()


## --- Lighting ------------------------------------------------------------

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.04, 0.04, 0.04)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.2, 0.2, 0.2)   # #333 feel
	env.ambient_light_energy = 0.4
	env.fog_enabled = true
	env.fog_light_color = Color(0.1, 0.0, 0.0)
	env.fog_density = 0.015
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.light_color = RED
	sun.light_energy = 0.4
	sun.rotation = Vector3(deg_to_rad(-55), deg_to_rad(40), 0)
	sun.shadow_enabled = true
	add_child(sun)

	# Red accent omni lights at the corners.
	for c in [Vector3(-HALF + 4, 4, -HALF + 4), Vector3(HALF - 4, 4, HALF - 4),
			Vector3(-HALF + 4, 4, HALF - 4), Vector3(HALF - 4, 4, -HALF + 4)]:
		var o := OmniLight3D.new()
		o.light_color = RED
		o.light_energy = 1.2
		o.omni_range = 18.0
		o.position = c
		add_child(o)


## --- Geometry ------------------------------------------------------------

func _build_floor() -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	add_child(body)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(ARENA_SIZE, 1, ARENA_SIZE)
	shape.shape = box
	shape.position = Vector3(0, -0.5, 0)
	body.add_child(shape)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(ARENA_SIZE, 1, ARENA_SIZE)
	mi.mesh = mesh
	mi.position = Vector3(0, -0.5, 0)
	mi.material_override = _mat(ground_color)
	body.add_child(mi)


func _build_walls() -> void:
	var specs := [
		[Vector3(0, WALL_HEIGHT * 0.5, -HALF), Vector3(ARENA_SIZE, WALL_HEIGHT, 1)],
		[Vector3(0, WALL_HEIGHT * 0.5, HALF), Vector3(ARENA_SIZE, WALL_HEIGHT, 1)],
		[Vector3(-HALF, WALL_HEIGHT * 0.5, 0), Vector3(1, WALL_HEIGHT, ARENA_SIZE)],
		[Vector3(HALF, WALL_HEIGHT * 0.5, 0), Vector3(1, WALL_HEIGHT, ARENA_SIZE)],
	]
	for s in specs:
		_make_box(s[0], s[1], obstacle_color)


func _build_obstacles() -> void:
	# 15-20 hiding spots, deterministic per map seed, kept clear of centre.
	var placed := 0
	var attempts := 0
	while placed < OBSTACLE_COUNT and attempts < 200:
		attempts += 1
		var pos := Vector3(_rng.randf_range(-HALF + 5, HALF - 5), 0,
				_rng.randf_range(-HALF + 5, HALF - 5))
		if pos.length() < 6.0:
			continue   # keep hunter spawn area open
		_make_obstacle(pos)
		placed += 1


## Style-specific obstacle primitive (placeholder for Quaternius models).
func _make_obstacle(pos: Vector3) -> void:
	match style:
		Style.FOREST:
			# "tree": trunk + canopy cone.
			var h := _rng.randf_range(3.0, 5.0)
			_make_cylinder(pos + Vector3(0, h * 0.5, 0), 0.4, h, Color(0.15, 0.1, 0.07))
		Style.WAREHOUSE:
			# stacked crates.
			var n := _rng.randi_range(1, 3)
			for i in n:
				_make_box(pos + Vector3(0, 1.0 + i * 2.0, 0), Vector3(2, 2, 2), obstacle_color)
		Style.MANSION:
			# interior partition wall + furniture block.
			_make_box(pos + Vector3(0, 1.5, 0), Vector3(_rng.randf_range(3, 6), 3, 0.5), obstacle_color)
		_:
			# URBAN: rectangular building block.
			var w := _rng.randf_range(3, 6)
			var ht := _rng.randf_range(4, 9)
			_make_box(pos + Vector3(0, ht * 0.5, 0), Vector3(w, ht, w), obstacle_color)


func _build_spawns() -> void:
	var root := Node3D.new()
	root.name = "SpawnPoints"
	add_child(root)
	# Hunter: centre.
	var h := Marker3D.new()
	h.name = "HunterSpawn"
	h.position = Vector3(0, 1, 0)
	root.add_child(h)
	# Hunted/ghost: 8 perimeter points.
	for i in PERIMETER_SPAWNS:
		var ang := TAU * float(i) / float(PERIMETER_SPAWNS)
		var m := Marker3D.new()
		m.name = "Spawn%d" % i
		m.position = Vector3(cos(ang) * (HALF - 4), 1, sin(ang) * (HALF - 4))
		root.add_child(m)


## --- primitive helpers ---------------------------------------------------

func _make_box(center: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.position = center
	add_child(body)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = _mat(color)
	body.add_child(mi)


func _make_cylinder(center: Vector3, radius: float, height: float, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.position = center
	add_child(body)
	var shape := CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = radius
	cyl.height = height
	shape.shape = cyl
	body.add_child(shape)
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mi.mesh = mesh
	mi.material_override = _mat(color)
	body.add_child(mi)


func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	return m
