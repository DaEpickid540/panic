# Panic: Arena

A multiplayer horror game built in **Godot 4.6.3**, exporting to **HTML5 / PWA**.
Each round is a hunt across a dark arena:

- **Hunter** — first-person, flashlight, 5 m/s. Raycast-grabs the hunted (5 m).
- **Hunted** — isometric, 6 m/s (fast but blind-ish). Navigates by **audio only**:
  a continuous horror loop and nothing else but the sound of being caught.
- **Ghost** — captured players. Isometric, 2 m/s, walks through walls. Can grab a
  hunted player (≤3 m), scream, and mute their audio for 5 s.

Realtime multiplayer runs over **Firebase Realtime Database**; **Cloud Functions**
own authoritative role assignment + phase validation.

> **Live builds:** itch.io → `<!-- LINK -->` · GitHub Pages → `<!-- LINK -->`
> (add after deploying — see [DEPLOY.md](DEPLOY.md)).

> Theme: dark `#1a1a1a` + red `#CC0000`, in `assets/panic_theme.tres` and every UI.

---

## Play / controls

| | Desktop | Mobile |
| --- | --- | --- |
| Move | `WASD` | Virtual joystick (bottom-left) |
| Look (hunter) | Mouse | Drag / tilt |
| Capture (hunter) | Left click | Tap |
| Grab (ghost) | `E` / Left click | Tap |
| Release mouse | `Esc` | — |

## Game phases

`LOBBY → COUNTDOWN (5 s) → HUNTING (5–20 min, default 5) → END`

The whole loop is **testable in the editor with no Firebase and no assets** — see
[TESTING.md](TESTING.md) section A (Host → Add Test Player → Start).

---

## Project layout

```
panic/
├─ project.godot                # autoloads, input map, theme, web/mobile settings
├─ default_bus_layout.tres      # Master / Music / SFX / Voice buses
├─ scenes/
│  ├─ Main.tscn                 # ROOT (main scene): World + phase UI
│  ├─ Player.tscn               # CharacterBody3D, FPS + iso cameras, flashlight
│  ├─ Hunter.tscn / Ghost.tscn  # Player presets (role baked in)
│  ├─ RemotePlayer.tscn         # interpolated remote avatar (+capture body)
│  ├─ Map.tscn                  # generic procedural arena
│  ├─ maps/ Urban|Forest|Warehouse|Mansion.tscn
│  ├─ LobbyUI / CountdownUI / HuntingUI / EndUI .tscn
│  └─ VirtualJoystick.tscn
├─ scripts/
│  ├─ GameManager.gd            # phases, timer (5–20m), roles, results  (autoload)
│  ├─ FirebaseManager.gd        # RTDB client, offline-safe              (autoload)
│  ├─ GameStateSync.gd          # phase/time/roles/captures/grabs sync   (autoload)
│  ├─ NetworkManager.gd         # peers, room codes, test bots           (autoload)
│  ├─ AudioManager.gd           # 8 loops + SFX, crossfade, master vol   (autoload)
│  ├─ TouchInput.gd             # mobile input bridge                    (autoload)
│  ├─ PlayerController.gd       # movement + per-role cameras/speeds
│  ├─ PlayerSpawner.gd          # local + remote spawning at spawn points
│  ├─ PositionSync.gd           # 10 Hz transform sync + interpolation + disconnects
│  ├─ RemotePlayer.gd           # remote avatar interpolation
│  ├─ HuntedAudioController.gd  # audio-only loop machine (mute on grab)
│  ├─ Hunter3DAudio.gd          # 3D footsteps / capture / scream
│  ├─ CaptureDetector.gd        # hunter raycast capture
│  ├─ GhostController.gd        # ghost grab / reveal / escape
│  ├─ ProximityDetector.gd      # distance queries
│  ├─ EndCondition.gd           # end-of-match hook
│  ├─ MapBase.gd                # procedural 50×50 arena (primitives → swap for .glb)
│  ├─ GameController.gd         # in-match orchestrator (World node)
│  ├─ UIManager.gd / Main.gd    # phase-screen switching + glue
│  └─ Lobby/Countdown/Hunting/End UI.gd, MiniMap.gd, VirtualJoystick.gd, UiFx.gd
├─ firebase/
│  ├─ functions/index.js        # POST /assignRoles + validation/disconnect triggers
│  ├─ database.rules.json       # RTDB security rules
│  └─ firebase.json             # hosting + WASM/COOP/COEP headers
├─ pwa/  index.html · manifest.json · service-worker.js · icons/
├─ build.sh / build.ps1         # headless export + PWA overlay
├─ export_presets.cfg           # Web preset (PWA on, threads off, mobile VRAM)
├─ ASSETS.md · TESTING.md · DEPLOY.md
└─ README.md
```

---

## Getting started

### Open in Godot
Install **Godot 4.6.3** (standard build — GDScript only, no C#), import
`project.godot`, press **F5**. Main scene is `scenes/Main.tscn`.

### Wire up Firebase (for real multiplayer)
1. Create a Firebase project; enable **Realtime Database** + **Anonymous Auth**.
2. Put your config in `pwa/index.html` *and* either `scripts/FirebaseManager.gd`
   `CONFIG` or a git-ignored `firebase_config.json` at the project root.
   (While the `apiKey` is `YOUR_API_KEY`, the game runs offline/local-only.)
3. Deploy rules + functions:
   ```bash
   cd firebase && npm --prefix functions install
   firebase deploy --only database,functions
   ```
   The HTML5 client gets roles by POSTing `{ playerId, totalPlayers, gameId }`
   to the `assignRoles` function (one random hunter per game, transaction-safe).

### Export to HTML5 / PWA
See [DEPLOY.md](DEPLOY.md). Short version: `./build.sh` (or `.\build.ps1`) →
`build/html5/`. The `Web` preset has **PWA enabled** and **threads disabled**
(so it works on itch.io / GitHub Pages without COOP/COEP headers).

### Add real assets
Primitives, silence, and default fonts are placeholders so the project runs
immediately. Drop in CC0 assets per **[ASSETS.md](ASSETS.md)**:
- Models → `assets/models/` (Quaternius), swap into `MapBase._make_obstacle()`.
- Audio  → `assets/audio/loops/horror_01..08.ogg`, `assets/audio/sfx/*.wav`
  (names are in `AudioManager.LOOP_PATHS` / `SFX_PATHS`).
- Fonts  → `assets/fonts/Orbitron.ttf`, `SpaceMono.ttf`; wire into the theme.

---

## Credits

- **Engine:** [Godot](https://godotengine.org) (MIT).
- **3D models:** [Quaternius](https://quaternius.com) (CC0).
- **Textures:** [Poly Haven](https://polyhaven.com), [ambientCG](https://ambientcg.com) (CC0).
- **Audio:** [Freesound](https://freesound.org) (CC0), [Zapsplat](https://zapsplat.com),
  YouTube Audio Library.
- **Fonts:** [Orbitron](https://fonts.google.com/specimen/Orbitron),
  [Space Mono](https://fonts.google.com/specimen/Space+Mono) (SIL OFL).

Record per-asset attribution in `CREDITS.md` as you add files.

## Constraints honored

Godot 4.6.3 GDScript only · Firebase **Realtime DB** (not Firestore) · HTML5 +
mobile (touch joystick, viewport meta) · dark `#1a1a1a` + red `#CC0000` theme ·
hunter FPS (no body) / hunted+ghost isometric · capture instant · audio routed
per role (hunted audio-only, hunter 3D, ghost silent).
