extends Control
## HuntingUI — role label, round timer, mini-map (hunter only), mobile stick.
## Hunted players see almost nothing (audio-only) beyond a stark role banner.

@onready var _role: Label = $TopBar/RoleLabel
@onready var _timer: Label = $TopBar/TimerLabel
@onready var _minimap: Control = $MiniMap
@onready var _joystick: Control = $VirtualJoystick
@onready var _grip_banner: Label = $GripBanner


func _ready() -> void:
	GameManager.hunting_tick.connect(_on_tick)
	GameManager.hunting_started.connect(_refresh_role)
	GameManager.role_assigned.connect(func(id, _r): if id == NetworkManager.local_peer_id: _refresh_role())
	_joystick.visible = TouchInput.enabled
	_grip_banner.visible = false


func _refresh_role() -> void:
	var role := GameManager.get_local_role()
	match role:
		GameManager.Role.HUNTER:
			_role.text = "HUNTER"
			_minimap.visible = true
		GameManager.Role.HUNTED:
			_role.text = "HUNTED — LISTEN"
			_minimap.visible = false
		GameManager.Role.GHOST:
			_role.text = "GHOST"
			_minimap.visible = false


func _on_tick(seconds_left: int) -> void:
	_timer.text = "%02d:%02d" % [seconds_left / 60, seconds_left % 60]


## Called by GhostController via signal wiring (set up in Main).
func show_grip(active: bool) -> void:
	_grip_banner.visible = active
	_grip_banner.text = "GRABBED — RUN!" if active else ""
