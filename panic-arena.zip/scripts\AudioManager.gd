extends Node
## AudioManager (autoload singleton)
##
## Central audio library + mixing for "Panic: Arena".
##   - 8 pre-loaded horror ambient loops (CC0; ~2 min each) with 1s crossfade.
##   - SFX pack (countdown_beep, capture, ghost_scream, phase_change).
##   - Master volume control.
##
## Role routing is implemented by node controllers attached to the local
## player (HuntedAudioController / Hunter3DAudio); this singleton is the shared
## library + the music-bed crossfade machine they drive.
##
## Loads are guarded by ResourceLoader.exists() so the project runs with NO
## audio assets present — drop real .ogg/.wav files in assets/audio/ later.

signal loop_changed(index: int)

const FADE_TIME := 1.0

## Horror ambient loops — replace with real CC0 files (see ASSETS.md).
const LOOP_PATHS := [
	"res://assets/audio/loops/horror_01.ogg",
	"res://assets/audio/loops/horror_02.ogg",
	"res://assets/audio/loops/horror_03.ogg",
	"res://assets/audio/loops/horror_04.ogg",
	"res://assets/audio/loops/horror_05.ogg",
	"res://assets/audio/loops/horror_06.ogg",
	"res://assets/audio/loops/horror_07.ogg",
	"res://assets/audio/loops/horror_08.ogg",
]

const SFX_PATHS := {
	"countdown_beep": "res://assets/audio/sfx/countdown_beep.wav",
	"capture": "res://assets/audio/sfx/capture.wav",
	"ghost_scream": "res://assets/audio/sfx/ghost_scream.wav",
	"phase_change": "res://assets/audio/sfx/phase_change.wav",
	"footstep": "res://assets/audio/sfx/footstep.wav",
}

var loops: Array = []            # Array[AudioStream] (null if missing)
var sfx: Dictionary = {}         # name -> AudioStream (or null)
var current_loop: int = -1

var _player_a: AudioStreamPlayer
var _player_b: AudioStreamPlayer
var _active_is_a := true
var _tween: Tween


func _ready() -> void:
	_player_a = _make_music_player()
	_player_b = _make_music_player()
	_preload()


func _make_music_player() -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.bus = "Music"
	p.volume_db = -80.0
	add_child(p)
	return p


func _preload() -> void:
	loops.clear()
	for path in LOOP_PATHS:
		loops.append(load(path) if ResourceLoader.exists(path) else null)
	for name in SFX_PATHS:
		var path: String = SFX_PATHS[name]
		sfx[name] = load(path) if ResourceLoader.exists(path) else null


## --- SFX -----------------------------------------------------------------

## Fire a non-positional one-shot (UI/global cues). Returns the player so the
## caller can stop it (e.g. capture mute).
func play_sfx(name: String, volume_db: float = 0.0) -> AudioStreamPlayer:
	var stream = sfx.get(name)
	if stream == null:
		# Asset missing — log once so tests still pass silently.
		return null
	var p := AudioStreamPlayer.new()
	p.bus = "SFX"
	p.stream = stream
	p.volume_db = volume_db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()
	return p


func get_sfx_stream(name: String) -> AudioStream:
	return sfx.get(name)


## --- Music-bed crossfade -------------------------------------------------

## Crossfade the music bed to loop `index` over FADE_TIME seconds.
func crossfade_to(index: int) -> void:
	if index < 0 or index >= loops.size():
		return
	current_loop = index
	loop_changed.emit(index)

	var stream = loops[index]
	if stream == null:
		return   # nothing to play, but state is tracked for tests

	var incoming := _player_b if _active_is_a else _player_a
	var outgoing := _player_a if _active_is_a else _player_b
	_active_is_a = not _active_is_a

	incoming.stream = stream
	incoming.volume_db = -80.0
	incoming.play()

	if _tween and _tween.is_running():
		_tween.kill()
	_tween = create_tween().set_parallel(true)
	_tween.tween_property(incoming, "volume_db", 0.0, FADE_TIME)
	_tween.tween_property(outgoing, "volume_db", -80.0, FADE_TIME)
	_tween.chain().tween_callback(outgoing.stop)


func stop_music(fade := true) -> void:
	for p in [_player_a, _player_b]:
		if fade and p.playing:
			var t := create_tween()
			t.tween_property(p, "volume_db", -80.0, FADE_TIME)
			t.tween_callback(p.stop)
		else:
			p.stop()


## --- Master volume -------------------------------------------------------

## linear 0.0..1.0
func set_master_volume(linear: float) -> void:
	var idx := AudioServer.get_bus_index("Master")
	if idx >= 0:
		AudioServer.set_bus_volume_db(idx, linear_to_db(clampf(linear, 0.0001, 1.0)))


func get_master_volume() -> float:
	var idx := AudioServer.get_bus_index("Master")
	return db_to_linear(AudioServer.get_bus_volume_db(idx)) if idx >= 0 else 1.0
