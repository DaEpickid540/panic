extends CharacterBody3D
## PlayerController
##
## Local player movement + per-role camera. One script, three behaviours:
##   HUNTER  — FPS: mouse/tilt look, body yaw rotates, no visible body, 5 m/s.
##   HUNTED  — isometric third-person, fixed camera angle, collision, 6 m/s.
##   GHOST   — isometric third-person, slow 2 m/s, no environment collision.
##
## Movement input merges WASD (Input map) with the mobile VirtualJoystick
## (TouchInput.move). No position networking here — PositionSync reads our
## transform; remote avatars are interpolated by RemotePlayer.

# Keyed by GameManager.Role int (0=HUNTER, 1=HUNTED, 2=GHOST). Literal keys so
# this stays a compile-time constant (autoload enums aren't const-foldable).
const SPEED := {
	0: 5.0,   # HUNTER
	1: 6.0,   # HUNTED
	2: 2.0,   # GHOST
}

@export var mouse_sensitivity := 0.0025
@export var gravity := 18.0

# 0 = HUNTER, 1 = HUNTED, 2 = GHOST (GameManager.Role). Exported so inherited
# scenes (Hunter.tscn / Ghost.tscn) can preset it in the editor.
@export var role: int = 1
var peer_id: int = -1
var is_local := true

@onready var _mesh: Node3D = $Mesh
@onready var _fps_cam: Camera3D = $Head/FPSCamera
@onready var _iso_cam: Camera3D = $IsoPivot/IsoCamera
@onready var _flashlight: SpotLight3D = $Head/Flashlight

var _yaw := 0.0
var _pitch := 0.0


func _ready() -> void:
	if is_local:
		peer_id = NetworkManager.local_peer_id
	configure_for_role(role)


## Set up cameras / collision / model visibility for a role. Public so the
## spawner (and editor tests) can re-apply when a role changes.
func configure_for_role(new_role: int) -> void:
	role = new_role
	_flashlight.visible = (role == GameManager.Role.HUNTER and is_local)
	match role:
		GameManager.Role.HUNTER:
			_mesh.visible = false                # first-person: no body
			collision_mask = 1                   # collide with world
			gravity = 18.0
			if is_local:
				_fps_cam.current = true
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		GameManager.Role.HUNTED:
			_mesh.visible = true
			collision_mask = 1
			gravity = 18.0
			if is_local:
				_iso_cam.current = true
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		GameManager.Role.GHOST:
			_mesh.visible = true
			_set_ghost_transparency()
			collision_mask = 0                   # walk through walls
			gravity = 0.0
			if is_local:
				_iso_cam.current = true
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _unhandled_input(event: InputEvent) -> void:
	if not is_local or role != GameManager.Role.HUNTER:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_apply_look(-event.relative.x * mouse_sensitivity, -event.relative.y * mouse_sensitivity)
	elif event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _physics_process(delta: float) -> void:
	if not is_local:
		return

	# Mobile look (tilt/drag) for the hunter.
	if role == GameManager.Role.HUNTER and TouchInput.enabled:
		var l := TouchInput.consume_look()
		_apply_look(-l.x * mouse_sensitivity, -l.y * mouse_sensitivity)

	# Gravity
	if gravity > 0.0 and not is_on_floor():
		velocity.y -= gravity * delta
	elif gravity > 0.0:
		velocity.y = 0.0

	var input := _get_move_input()
	var speed: float = SPEED.get(role, 5.0)
	var dir := _input_to_world_dir(input)

	velocity.x = dir.x * speed
	velocity.z = dir.z * speed
	move_and_slide()

	# Iso roles: face the mesh toward movement (camera angle stays fixed).
	if role != GameManager.Role.HUNTER and dir.length() > 0.1:
		var target := atan2(dir.x, dir.z)
		_mesh.rotation.y = lerp_angle(_mesh.rotation.y, target, 0.2)


## --- helpers -------------------------------------------------------------

func _get_move_input() -> Vector2:
	var kb := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var t := TouchInput.move if TouchInput.enabled else Vector2.ZERO
	var combined := kb + t
	return combined.limit_length(1.0)


func _input_to_world_dir(input: Vector2) -> Vector3:
	if role == GameManager.Role.HUNTER:
		# Relative to body yaw (FPS).
		return (transform.basis * Vector3(input.x, 0, input.y)).normalized() if input != Vector2.ZERO else Vector3.ZERO
	# Iso: camera-relative on a fixed 45° grid (body never rotates).
	if input == Vector2.ZERO:
		return Vector3.ZERO
	return Vector3(input.x, 0, input.y).normalized()


func _apply_look(dyaw: float, dpitch: float) -> void:
	_yaw += dyaw
	_pitch = clampf(_pitch + dpitch, -1.4, 1.4)
	rotation.y = _yaw
	$Head.rotation.x = _pitch


func _set_ghost_transparency() -> void:
	var mi := _mesh as MeshInstance3D
	if mi == null:
		return
	var mat := StandardMaterial3D.new()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.8, 0.0, 0.0, 0.35)
	mi.material_override = mat
