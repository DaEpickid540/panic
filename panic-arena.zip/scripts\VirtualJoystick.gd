extends Control
## VirtualJoystick
##
## On-screen thumbstick for mobile. Writes a normalised vector to
## TouchInput.move so PlayerController treats it like keyboard input. The stick
## appears only on touch devices; on desktop it hides itself.
##
## Layout: a fixed base ring with a draggable knob. Touch anywhere inside the
## base captures the stick; release re-centres it.

@export var radius := 90.0
@export var dead_zone := 0.15

@onready var _base: Control = $Base
@onready var _knob: Control = $Base/Knob

var _touch_index := -1
var _center := Vector2.ZERO


func _ready() -> void:
	visible = TouchInput.enabled
	_center = _base.global_position + _base.size * 0.5


func _gui_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_update(event.position)
		elif not event.pressed and event.index == _touch_index:
			_release()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		_update(event.position)
	# Mouse fallback so it works in the editor too.
	elif event is InputEventMouseButton:
		if event.pressed:
			_touch_index = 0
			_update(event.position)
		else:
			_release()
	elif event is InputEventMouseMotion and _touch_index == 0:
		_update(event.position)


func _update(local_pos: Vector2) -> void:
	var offset := (local_pos - _base.position - _base.size * 0.5)
	offset = offset.limit_length(radius)
	_knob.position = _base.size * 0.5 + offset - _knob.size * 0.5
	var v := offset / radius
	TouchInput.move = v if v.length() > dead_zone else Vector2.ZERO


func _release() -> void:
	_touch_index = -1
	TouchInput.move = Vector2.ZERO
	_knob.position = _base.size * 0.5 - _knob.size * 0.5
