extends Control
## EndUI — survivor list + stats table (name, role, survival time, captures).

@onready var _headline: Label = $Panel/VBox/Headline
@onready var _survivors: Label = $Panel/VBox/Survivors
@onready var _rows: VBoxContainer = $Panel/VBox/StatsTable/Rows
@onready var _play_again: Button = $Panel/VBox/PlayAgain


func _ready() -> void:
	GameManager.game_ended.connect(_on_ended)


func _on_ended(results: Dictionary) -> void:
	var reason: String = results.get("reason", "timer")
	_headline.text = "ALL CAPTURED" if reason == "all_captured" else "TIME'S UP"
	_survivors.text = "SURVIVORS: %d" % results.get("survivor_count", 0)
	for c in _rows.get_children():
		c.queue_free()
	for s in results.get("stats", []):
		_rows.add_child(_make_row(s))


func _make_row(s: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	_cell(row, s.get("name", "?"), 160)
	_cell(row, str(s.get("role", "")).to_upper(), 90)
	var t: int = s.get("survival_time", 0)
	_cell(row, "%02d:%02d" % [t / 60, t % 60], 80)
	_cell(row, "x%d" % s.get("captures", 0), 60)
	return row


func _cell(row: HBoxContainer, text: String, width: int) -> void:
	var l := Label.new()
	l.text = text
	l.custom_minimum_size = Vector2(width, 0)
	row.add_child(l)


func _on_play_again_pressed() -> void:
	GameManager.force_phase(GameManager.Phase.LOBBY)
