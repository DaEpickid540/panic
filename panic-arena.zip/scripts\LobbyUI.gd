extends Control
## LobbyUI — player roster, map selection, round-length slider, Start.
## Dark + red theme. Writes the selected map + round length into GameManager
## (mirrored to Firebase when the host starts).

const MAPS := ["Urban", "Forest", "Warehouse", "Mansion"]

@onready var _count: Label = $Panel/VBox/PlayerCount
@onready var _list: VBoxContainer = $Panel/VBox/PlayerList
@onready var _room: Label = $Panel/VBox/RoomCode
@onready var _map_buttons: HBoxContainer = $Panel/VBox/MapRow
@onready var _timer_slider: HSlider = $Panel/VBox/TimerRow/TimerSlider
@onready var _timer_label: Label = $Panel/VBox/TimerRow/TimerValue


func _ready() -> void:
	NetworkManager.peer_joined.connect(func(_id): _refresh())
	NetworkManager.peer_left.connect(func(_id): _refresh())
	_timer_slider.min_value = GameManager.MIN_ROUND_MINUTES
	_timer_slider.max_value = GameManager.MAX_ROUND_MINUTES
	_timer_slider.value = GameManager.round_minutes
	_timer_slider.value_changed.connect(_on_timer_changed)
	_build_map_buttons()
	_highlight_map(GameManager.selected_map)
	_refresh()
	UiFx.wire_buttons(self)


func _refresh() -> void:
	_count.text = "PLAYERS: %d" % NetworkManager.get_peer_count()
	for c in _list.get_children():
		c.queue_free()
	for id in NetworkManager.get_peer_ids():
		var l := Label.new()
		l.text = "• " + NetworkManager.get_peer_name(id)
		_list.add_child(l)
	if NetworkManager.current_room != "":
		_room.text = "ROOM: " + NetworkManager.current_room


func _build_map_buttons() -> void:
	for name in MAPS:
		var b := Button.new()
		b.text = name.to_upper()
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(0, 48)   # touch target
		b.pressed.connect(func(): _select_map(name))
		_map_buttons.add_child(b)


func _select_map(name: String) -> void:
	GameManager.selected_map = name
	_highlight_map(name)


func _highlight_map(name: String) -> void:
	for b in _map_buttons.get_children():
		(b as Button).button_pressed = (b.text == name.to_upper())


func _on_timer_changed(v: float) -> void:
	GameManager.set_round_minutes(int(v))
	_timer_label.text = "%d MIN" % GameManager.round_minutes


func _on_host_pressed() -> void:
	NetworkManager.host_room()
	_refresh()


func _on_add_bot_pressed() -> void:
	NetworkManager.add_test_peer()


func _on_start_pressed() -> void:
	GameManager.start_game()
