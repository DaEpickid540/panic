extends Node
## FirebaseManager (autoload singleton)
##
## Thin client for Firebase Realtime Database over the REST/streaming API.
## We use the REST API (HTTPRequest) rather than the native SDK because the
## game ships to HTML5 — the JS SDK is reachable through JavaScriptBridge when
## running in-browser, and the REST fallback keeps the editor/desktop usable.
##
## SECURITY NOTE: the values below are *client* config (safe to ship) — the
## Realtime DB is protected by Security Rules, NOT by hiding this config.
## Replace the placeholders with your project's values, or load them from
## an exported `firebase_config.json` so they are not committed.

signal ready_changed(is_ready: bool)
signal db_value(path: String, value: Variant)
signal db_error(path: String, code: int)

# ---------------------------------------------------------------------------
# CONFIG — replace with your Firebase project credentials.
# ---------------------------------------------------------------------------
const CONFIG := {
	"apiKey": "YOUR_API_KEY",
	"authDomain": "panic-arena.firebaseapp.com",
	"databaseURL": "https://panic-arena-default-rtdb.firebaseio.com",
	"projectId": "panic-arena",
	"storageBucket": "panic-arena.appspot.com",
	"messagingSenderId": "YOUR_SENDER_ID",
	"appId": "YOUR_APP_ID",
}

var is_ready: bool = false
## False while CONFIG still holds placeholder credentials — all DB calls no-op
## so the full game is playable in the editor with NO Firebase project.
var enabled: bool = false
var _id_token: String = ""          # set after anonymous auth
var _running_in_browser: bool = false


func _ready() -> void:
	_running_in_browser = OS.has_feature("web")
	_load_config_override()
	enabled = CONFIG.get("apiKey", "") != "" and CONFIG.get("apiKey") != "YOUR_API_KEY"
	if enabled:
		initialize()
	else:
		print("[FirebaseManager] Placeholder credentials — running OFFLINE (local play only).")


## Optionally load credentials from res:// or user:// so they are not baked
## into source control. Falls back to the CONFIG constant above.
func _load_config_override() -> void:
	var path := "res://firebase_config.json"
	if not FileAccess.file_exists(path):
		return
	var f := FileAccess.open(path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if typeof(parsed) == TYPE_DICTIONARY:
		for k in parsed:
			CONFIG[k] = parsed[k]


func initialize() -> void:
	# In-browser we defer to the JS SDK loaded by index.html; on desktop we
	# talk to the REST endpoint directly. Either way we sign in anonymously.
	_authenticate_anonymous()


func _authenticate_anonymous() -> void:
	# TODO: POST to identitytoolkit signUp?key=API_KEY, store _id_token.
	# For now mark ready so the rest of the stack can be developed offline.
	is_ready = true
	ready_changed.emit(true)


## --- Realtime DB helpers -------------------------------------------------
## Paths are relative to databaseURL, e.g. "rooms/ABC123/players/12".

func db_put(path: String, value: Variant) -> void:
	_request(HTTPClient.METHOD_PUT, path, value)


func db_patch(path: String, value: Dictionary) -> void:
	_request(HTTPClient.METHOD_PATCH, path, value)


func db_get(path: String) -> void:
	_request(HTTPClient.METHOD_GET, path, null)


func db_delete(path: String) -> void:
	_request(HTTPClient.METHOD_DELETE, path, null)


## Subscribe to a path. In browser this attaches a JS onValue listener;
## on desktop it falls back to polling (implement as needed).
func db_listen(path: String) -> void:
	# TODO: EventSource (SSE) for REST, or JavaScriptBridge onValue for web.
	pass


func _request(method: int, path: String, body: Variant) -> void:
	if not enabled:
		return   # offline mode — no network traffic
	var url := "%s/%s.json" % [CONFIG.databaseURL, path]
	if _id_token != "":
		url += "?auth=" + _id_token
	var req := HTTPRequest.new()
	add_child(req)
	req.request_completed.connect(
		func(_r, code, _h, data): _on_response(req, path, code, data)
	)
	var headers := PackedStringArray(["Content-Type: application/json"])
	var payload := "" if body == null else JSON.stringify(body)
	var err := req.request(url, headers, method, payload)
	if err != OK:
		db_error.emit(path, err)
		req.queue_free()


func _on_response(req: HTTPRequest, path: String, code: int, data: PackedByteArray) -> void:
	req.queue_free()
	if code < 200 or code >= 300:
		db_error.emit(path, code)
		return
	var text := data.get_string_from_utf8()
	var value: Variant = JSON.parse_string(text) if text != "" else null
	db_value.emit(path, value)
